#include"Block0.h"

Block0::Block0()
{
	strcpy_s(information, "10101010");
	this->root = 5;
	this->startblock = 5;
}