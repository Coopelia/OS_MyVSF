#include"UIScene.h"

UIScene::UIScene()
{
	app = new RenderWindow(VideoMode(1280, 720), L"�����ļ�ϵͳ", Uint32(5));
	core_x = 150;
	core_y = 100;
	dx = 250;
	dy = 250;
	now_numFile = 0;
	SceneMode = 1;
	id_seleted = -1;
	font.loadFromFile("asset/fonts/fSimpleRound.ttf");
	txt.setFont(font);
	txt.setFillColor(Color::Black);
	txt.setCharacterSize(30);
	txt.setPosition(50, 100);
	tHightLight.loadFromFile("asset/image/hl.png");
	sHightLight.setTexture(tHightLight);
	tBackground.loadFromFile("assets/image/back.png");
	sBackground.setTexture(tBackground);
	tBg_dir.loadFromFile("asset/image/bg_dir.png");
	sBg_dir.setTexture(tBg_dir);
	tBg_new.loadFromFile("asset/image/bg_new.png");
	sBg_new.setTexture(tBg_new);
	tBg_path.loadFromFile("asset/image/bg_path.png");
	sBg_path.setTexture(tBg_path);
	tBg_txt.loadFromFile("asset/image/bg_txt.png");
	sBg_txt.setTexture(tBg_txt);
	bt_cancel.setTextrue("asset/image/cancel.png");
	bt_close.setTextrue("asset/image/close.png");
	bt_delete.setTextrue("asset/image/ɾ��.png");
	bt_newDir.setTextrue("asset/image/�½��ļ���.png");
	bt_newTxt.setTextrue("asset/image/�½��ļ�.png");
	bt_ok.setTextrue("asset/image/ok.png");
	bt_open.setTextrue("asset/image/��.png");
	bt_save.setTextrue("asset/image/����.png");
	bt_edit.setTextrue("asset/image/edit.png");
}

void UIScene::Start()
{
	//��Ӳ���ж�ȡ�ļ�ϵͳ�����û�оʹ�һ��
	std::ifstream fin("asset/myvfs.txt", std::ios::in);
	if (!fin.is_open())
	{
		std::cout << "û���ҵ�ϵͳ��������һ����ϵͳ\n";
		vfs.sys_format();
		std::cout << "�����ɹ���\n";
	}
	else
	{
		std::cout << "�ҵ��ļ�ϵͳ\n";
		std::string str;
		char ct[8];
		bool flag = false;
		str.resize(SIZE);
		for (int i = 0; i < SIZE; i++)
		{
			fin >> str[i];
			if (i == 7)
			{
				if (strcmp(str.c_str(), "10101010") != 0)
				{
					std::cout << "���ǺϷ����ļ�ϵͳ��������һ����ϵͳ\n";
					vfs.sys_format();
					std::cout << "�����ɹ���\n";
					flag = true;
					break;
				}
			}
		}
		if(!flag)
			vfs.sys_start(str);//��ʼ��
	}
	fin.close();

	this->app->setFramerateLimit(60);
	this->sBackground.setPosition(0, 0);
	this->sBg_dir.setPosition(30, 90);
	this->sBg_txt.setPosition(30, 90);
	this->sBg_path.setPosition(30, 70);
	this->sBg_new.setPosition(200, 300);
	this->bt_cancel.app = app;
	this->bt_cancel.setPosition(800, 320);
	this->bt_close.app = app;
	this->bt_close.setPosition(100, 10);
	this->bt_delete.app = app;
	this->bt_delete.setPosition(300, 10);
	this->bt_newDir.app = app;
	this->bt_newDir.setPosition(100, 10);
	this->bt_newTxt.app = app;
	this->bt_newTxt.setPosition(200, 10);
	this->bt_open.app = app;
	this->bt_open.setPosition(30, 10);
	this->bt_ok.app = app;
	this->bt_ok.setPosition(700, 320);
	this->bt_save.app = app;
	this->bt_save.setPosition(30, 10);
	this->bt_edit.app = app;
	this->bt_edit.setPosition(30, 10);
}

void UIScene::show_now_path()
{
	for (int i = 0; i <= vfs.nowDir.dir_ser; i++)
		upath[i].show();
}

void UIScene::show_now_dir()
{
	app->draw(sBg_dir);
	bt_open.show();
	bt_newDir.show();
	bt_newTxt.show();
	bt_delete.show();
	app->draw(sHightLight);
	for (int i = 0; i < now_numFile; i++)
		now_ls[now_numFile].show(app);
}

void UIScene::show_now_file()
{
	FCB fcb;
	vfs.get_fcb(id_seleted, fcb);
	now_file_content.clear();
	vfs.sys_read_file(fcb, now_file_content);
	txt.setString(now_file_content);
	app->draw(sBg_txt);
	app->draw(txt);
}

void UIScene::create_dir()
{

}

void UIScene::create_file()
{

}

void UIScene::write_file()
{

}


void UIScene::Input(Event& e)
{
	if (e.type == Event::Closed)
		app->close();
	if (bt_newTxt.onClick(e))
	{
		std::string name = "test1";
		int ret = vfs.sys_mkfile(name);
		if (ret == 1)
			std::cout << "������һ���ļ�\n";
		else if (ret == 0)
			std::cout << "����ʧ�ܣ���Ŀ¼���������\n";
		else if (ret == -1)
			std::cout << "����ʧ�ܣ�������\n";
		else
			std::cout << "����ʧ�ܣ�����ʣ��ռ䲻��\n";
	}
}

void UIScene::update_dir()
{
	FCB fcb;
	for (int i = 0; i < vfs.nowDir.fcb.num_son; i++)
	{
		vfs.get_fcb(vfs.nowDir.fcb.son[i], fcb);
		if (fcb.attribute == '0')
			now_ls[now_numFile].setType(T_DIR);
		else
			now_ls[now_numFile].setType(T_FILE);
		now_ls[now_numFile].setName(fcb.filename);
		now_ls[now_numFile].setScale(ICON_SCALE);
		now_ls[now_numFile].setPosition(core_x + (now_numFile % 4) * dx, core_y + (now_numFile / 4) * dy);
		now_numFile++;
	}
	for (int i = 0; i <= vfs.nowDir.dir_ser; i++)
	{
		vfs.get_fcb(vfs.nowDir.dir_first[i], fcb);
		upath[i].Init(app);
		upath[i].setString(fcb.filename);
		upath[i].setPosition(i * 50 + 30, 50);
	}
	if (id_seleted != -1)
		sHightLight.setPosition(core_x + (id_seleted % 4) * dx - 5, core_y + (id_seleted / 4) * dy - 5);
	else
		sHightLight.setPosition(-300, -300);
}

void UIScene::Update()
{
	update_dir();
}

void UIScene::Draw()
{
	app->draw(sBackground);
	if (SceneMode == 1)
		show_now_dir();
	else if (SceneMode == 2)
		show_now_file();
	app->draw(sBg_path);
	show_now_path();

	app->display();
}

void UIScene::Exit()
{
	//���ڴ��е��ļ�ϵͳ���浽Ӳ��
	std::ofstream fout("asset/myvfs.txt", std::ios::trunc);
	for (int i = 0; i < SIZE; i++)
		fout << vfs.disk.vhard[i];
	fout.close();
	delete app;
}

void UIScene::run()
{
	Start();
	while (app->isOpen())
	{
		Event e;
		app->pollEvent(e);
		Draw();
		Input(e);
	}
	Exit();
}