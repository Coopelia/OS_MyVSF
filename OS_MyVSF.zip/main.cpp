#include"UIScene.h"

int main()
{
	UIScene scene;
	scene.run();

	return 0;
}